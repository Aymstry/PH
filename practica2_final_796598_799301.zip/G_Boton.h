#ifndef __G_BOTON_H__
#define __G_BOTON_H__

#include <inttypes.h>
#include "cola_asyn.h"

void gestor_botones(uint32_t auxData);
void desactivarAlarma(uint32_t auxData);

#endif
