//Tipo Abstracto de Datos. Encapsula el formato del tablero

/* guarda para evitar inclusiones m?ltiples ("include guard") */
#ifndef PRUEBAS_H_2022
#define PRUEBAS_H_2022



// funci�n principal del juego
void conecta4_jugar_test(void);



#endif /* PRUEBAS_H_2022 */
