#ifndef __MSG_H__
#define __MSG_H__
        // 0              1         2       
enum {Set_Alarma, Alarma_Vencida, Sleep}; 

#endif 
