#include "conecta4_2022.h"
#include "pruebas.h"
#include "entrada.h"

// MAIN 
int main (void) {
	
	// comente la linea que desea que no se ejecute 

	//jugar
	conecta4_jugar();
	// realización de las pruebas 
	conecta4_jugar_test();
	while(1); //no hay S.O., no se retorna
}
