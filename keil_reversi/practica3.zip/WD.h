#ifndef WD_H
#define WD_H
#include <inttypes.h>

void WD_init(int sec);
void WD_feed(void);


#endif