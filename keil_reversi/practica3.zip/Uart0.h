#ifndef UART0_H
#define UART0_H

#include <inttypes.h>

void uart0_init(void); 
int sendchar (int ch);  

#endif 
