#ifndef __GALARM_H__
#define __GALARM_H__
#include <inttypes.h>

void organizador_alarmas(uint32_t mensaje); 
void gestor_alarmas(void); 
void init_Parametros_GA(void);

#endif 

