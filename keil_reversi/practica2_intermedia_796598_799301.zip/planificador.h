#ifndef __PLANIFICADOR_H__
#define __PLANIFICADOR_H__

#include "cola_asyn.h"
#include "msg.h"
#include "eventos.h"
#include "G_Alarm.h"
#include "timer.h"
#include "G_Boton.h"
#include "botones.h"
#include "G_Power.h"
#include "power.h"
void planificador(void);

#endif
