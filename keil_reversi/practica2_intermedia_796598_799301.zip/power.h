#ifndef __POWER_H__
#define __POWER_H__

void power_down(void);
void idle(void); 

#endif 
