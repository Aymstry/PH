#ifndef __MSG_H__
#define __MSG_H__

enum {Set_Alarma, Alarma_Vencida, Sleep}; 

#endif 
