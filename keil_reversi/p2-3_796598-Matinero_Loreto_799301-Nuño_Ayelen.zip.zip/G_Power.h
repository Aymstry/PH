#ifndef __G_POWER_H__
#define __G_POWER_H__

#include "power.h"

void introducir_power(void);
void dormir(void);

#endif 
