#ifndef __POWER_H__
#define __POWER_H__

extern void switch_to_PLL(void);

void power_down(void);
void idle(void); 

#endif 
